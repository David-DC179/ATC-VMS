<?php 
require 'layout/login_header.php';
require 'function/login_logic.php';

?>

<!DOCTYPE html>
    <head>
        <link rel="stylesheet" href="asset/bootstrap/css/bootstrap.min.css">
    </head>
    <style>
        h6{
            color: #ffff;
            align-items:center;
        }
    </style>
<body>
    <div class="container">
       <br>
    
       <header class=" container col-md6 align-items-center">
                <div href="" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-light bg-success bouder-rounded bg-gradient text-decoration-none">
                    <img class="bi me-2" width="103" height="102" src="asset/image/logo.png" alt="logo">
                    <h1 class="h1 fw-bold "> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ATC VISTOR MANAGEMENT SYSTEM</h1>
                    
                </div>
                <div class=" bg-success mt-3 " style=" height: 8vh; width: 100%;"><br>
                <!-- <center><h6> VISTOR MANAGEMENT SYSTEM</h6></center> -->
                </div>
      
            </header>
             <div class="container row justify-content-center">
            <div class="container col-md-6 mt-5">
                <div class=" container card">
                    <div class="card-header"><p>LOGIN</p></div>

                    <div class="card-body">
                    <?php
                        if (count($errors) > 0) {
                            foreach($errors as $error) { ?>
                    <p class="alert alert-warning text-danger p-1">
                        <?php echo $error; ?>
                    </p>
                    <?php }
                        }
                    ?>
                    <form action="" method="post">
                    <div class="form-group">
                            <label for="">Username</label>
                            <input type="text" placeholder="eg habibu" class="form-control" name="username">
                        </div>

                        <div class="form-group">
                            <label for="">password</label>
                            <input type="password" class="form-control" name="password">
                        </div>

                        <div class="form-group">
                            <a href="#" class="ms-5" style="text-align:center; color:blue; text-decoration: none"> Forget password?</a>
                            
                        </div>

                        <div class="form-group mt-4">
                            <button type="submit" class="btn btn-success form-control" name="login">Login</button>
                        </div>
                    </form>
                        
                    </div>
                </div>
            </div>

           
               
            
        </div>


       
    </div>
                        <script src="asset/bootstrap/js/bootstrap.min.js"></script>
</body>
    
    <?php
require 'layout/login_footer.php';
?>