
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ATC-VMS</title>
    <link rel="shortcut icon" href="../asset/image/logo.png">
    
    <link rel="stylesheet" href="./asset/bootstrap/css/bootstrap.min.css">
</head>
<style>
    .img{
        float: left;
    }
    .txt{
        float: left;
        margin-left: 5%;
    }
</style>
<body>
    <div class="container ">
        <div class="row justify-content-center "  style="height:80vh;">
    
            <header class="mb-auto flex-wrap justify-content-center py-3 mb-4 " >
                <div class="d-flex align-items-center text-light bg-success" >
                    <br>
                
                    <img class="bi me-2" width="103" height="102" src="../asset/image/logo.png" alt="logo">
                    
                    <caption class="txt">
                    <center><h1>ATC VISTORS MANAGEMENT SYSTEM</h1></center>
                    </caption>
                    
                </div> 

<!-- <div class="container">
    <div class="img">
    <img class="bi me-2" width="103" height="102" src="../asset/image/logo.png" alt="logo">
    </div>
    <div class="txt">
    <center><h1>ARUSHA TECHNICAL COLLEGE</h1></center>
    </div>
</div>  -->