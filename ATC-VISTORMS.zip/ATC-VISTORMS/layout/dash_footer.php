</div>
    <head>
    <link rel="stylesheet" href="../asset/bootstrap/css/bootstrap.min.css">
    </head>

    <div class="container">
        <footer class="d-flex flex-wrap justify-content-between align-items-center py-3 my-4 border-top">
        <p class="col-md-4 mb-0 text-muted">&copy; 2022 Group Number One, ITD</p>

        <a href="/" class="col-md-4 d-flex align-items-center justify-content-center mb-3 mb-md-0 me-md-auto link-dark text-decoration-none">
        <!-- <img class="bi me-2" width="81" height="82" src="../asset/image/logo.png" alt="logo"> -->
        </a>

        <ul class="nav col-md-4 justify-content-end">
       
        
        <div class="dropstart ">
            <button class="btn btn-outline-success dropdown-toggle" type="button" id="dropstartMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
              ABOUT US
            </button>
            <ul class="dropdown-menu bg-success" aria-labelledby="dropstartMenuButton">
              <li><h6 class="dropdown-header fw-bold  fw-bold text-dark fw-bold">GROUP MEMBERS</h6></li>
              <li><a class="dropdown-item   text-dark fw-bold" href="#">David Christopher-database design & system developer</a></li>
              <li><a class="dropdown-item  text-dark fw-bold" href="#">Habibu Jumanne-system security & functionality</a></li>
              <li><a class="dropdown-item   text-dark fw-bold" href="#">Rabin Hassan-UI & UX design</a></li>
              <li><a class="dropdown-item   text-dark fw-bold" href="#">Jackline Mwasomolwa-system tester & requirement analysis</a></li>
              <li><a class="dropdown-item   text-dark fw-bold" href="#">Sayi Yona-system tester & requirement analysis</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item fw-bold text-light" href="#">Thanks</a></li>
            </ul>
        </div>  
        </ul>
        
  </footer>

  <script src="../asset/bootstrap/js/bootstrap.bundle.js"></script>
</div> 

       
 
</body>
</html>