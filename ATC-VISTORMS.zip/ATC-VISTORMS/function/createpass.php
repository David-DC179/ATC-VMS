<?php
    require 'db/connection.php';
    session_start();
    require 'functions.php';
    $username = $_SESSION['username'];
    $role = $_SESSION['role'];
    if(!isLoggedIn($username)){
        header("Location: ../index.php");
    }
    if(isAdmin($role)){
        header("Location: ../index.php");
    }
    require '../layout/dash_head.php';

?>

      
            <div class=" bg-success mt-3 " style=" height: 8vh; width: 100%;">
                <div class="col-md-3">
                    <a href="dashbord-Gurd.php" class="btn btn-dark m-2">BACK</a>
                </div>
            </div>
            <div class="container col-md-6"><br>
        <center><h1>CREATE PASS </h1></center>
            
            <form action="createpass_logic.php" method="post">
                    <div  class="form-group">
                        <label for="">First Name</label>
                        <input type="text" name="firstname" id="" class="form-control" placeholder="eg David" require> 
                        
                    </div>
                    <div  class="form-group">
                        <label for="">Last Name</label>
                        <input type="text" name="lastname" id="" class="form-control" placeholder="eg habibu" require> 
                        
                    </div>
                    <div class="form-group" >
                        <label for="">Gender</label>
                        <select name="gender" id="" class="form-control" placeholder="eg Male" require>
                            <option value="0">Select gender</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="">Phone</label>
                        <input type="text" name="phone" id="" class="form-control" placeholder="eg +255764063426"   require>
                    </div>
                     <div class="form-group">
                        <label for="">Address</label>
                        <input type="text" name="address" id="" class="form-control" placeholder="eg Sakina arusha" require>
                    </div>
                    <div class="form-group">
                        <label for="departiment">Select Department</label>
                       
                        <select name="departiment" id="" class="form-control"  require>
                            <option value="0">Select Departiment</option>
                            <?php
                                $select1 = "SELECT * FROM departiment";

                                $query = mysqli_query($conn,$select1);

                                if($rows=mysqli_num_rows($query)){
                                    
                                    
                                    while($departiment = mysqli_fetch_assoc($query)){
                                       $dept= $departiment['name'];
                                        
                                        ?>
                                       
                                        <option value="<?= $dept ?>" ><?php echo $dept ?></option>
                                     
                                            
                        <?php }


                                }
                            ?>
                            
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="">Whom to meet</label>
                        

                        <select name="employee" id="" class="form-control" placeholder="eg ICT" require>
                        <option value="">Select name</option>
                            <?php

                          
                                $select = "SELECT * FROM employees";

                                $query = mysqli_query($conn,$select);

                                if($rows=mysqli_num_rows($query)>0){
                                    

                                    while($employee = mysqli_fetch_assoc($query)){ 
                                        $empl = $employee['name'];
                                        
                                        ?>
                                       
                                        <option value="<?= $empl ?>"><?php echo $empl?></option>
                                     
                                            
                        <?php }


                                }
                            ?>
                            
                        </select>
                       
                    </div>

                    
                    <div class="form-group">
                        <label for="">Time IN</label>
                        <input type="datetime-local" name = "timein" class="form-control">
                       
                    </div>

                 

                    
                   <br>
                    <div class="form-group">
                        <button class="btn btn btn-success pull-right mb-5 w-100" type="submit" name="save">Save</button>
                    </div>
                </form>
            </div>
        </div>
    
<link rel="stylesheet" href="../asset/bootstrap/css/bootstrap.min.css">
    <div class="container">
  <script src="../asset/bootstrap/js/bootstrap.bundle.js"></script>
</div> 
</body>
</html>