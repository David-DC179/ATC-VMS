<?php
require 'login_logic.php';
header("Refresh: 60");
// require 'functions.php';
// $username = $_SESSION['username'];
$role = $_SESSION['role'];
// if(isLoggedIn($username) != true){
//     header("Location: ../login.php");
// }
require '../layout/dash_head.php';

?>
<head>
<link rel="stylesheet" href="../asset/bootstrap/css/bootstrap.min.css">
</head>
<div class=" bg-success mt-3 " style=" height: 8vh; width: 100%;">
                <?php 
                    if(isAdmin($role)){ ?>
                        <a href="dashbord-Admin.php" class="btn btn-dark m-2">BACK</a>

               <?php  }else{ ?>
                        <a href="dashbord-Gurd.php" class="btn btn-dark m-2">BACK</a>
             <?php  }
                ?>
                </div>
                    <div class="">
                        <h1 class="h1 fw-bold" style="text-align: center;">LIST OF VISTOR</h1>
                    </div>
           
        <div class="table-responsive-sm">
            <Table class="table  table-hover  table-striped border-success" style="text-align: center;">
               </div>
                <?php 
                    $select = "SELECT * FROM vistors";

                    $result = mysqli_query($conn,$select);

                    if(mysqli_num_rows($result)>0){

                        ?>
                   
                       
                <thead class="table bg-dark text-light">
                <th>SNO</th>
                <th colspan="2">FULL NAME</th>
                <th>GENDER</th>
                <th>ADDRESS</th>
                 <th>PHONE</th>
                <th colspan="2">DEPARTMENT</th>
                <th colspan="2">WHOSE TO MEET</th>
                <th colspan="">TIME IN</th>
                <th>TIME OUT</th>
            </thead> 

            <tbody>
                <?php  

                    $sn=1;
                    while($users=mysqli_fetch_assoc($result)){

                        $id_dept= $users['departiment_id'];
                        $id_employe= $users['employee_id'];

                        $selectd= "SELECT name FROM departiment WHERE id='$id_dept'";
                        $resultd = mysqli_query($conn,$selectd);
                        $departiment=mysqli_fetch_assoc($resultd);

                        $selecte= "SELECT name FROM employees WHERE id='$id_employe'";
                        $resulte = mysqli_query($conn,$selecte);
                        $employee=mysqli_fetch_assoc($resulte);
                    ?>
                    <tr>
                        <td><?php echo $sn++?></td>
                    <td><?php echo $users['first_name']?></td>
                    <td><?php echo $users['last_name']?></td>
                    <td><?php echo $users['gender']?></td>                    
                    <td><?php echo $users['address']?></td>
                    <td><?php echo $users['phone']?></td>
                    <td colspan="2"><?php echo $departiment['name']?></td>
                    <td colspan="2"><?php echo $employee['name']?></td>
                    <td><?php echo $users['time_in']?></td>
                    <td><?php echo $users['time_out']?></td>
                    <!-- <td class="btn btn-info sm">CHECK OUT</td> -->
                    <!-- <td><a href="checkout_logic.php?update=<?php echo$users['id'];?>" name="update" class="btn btn-info sm">CHECK OUT</a></td> -->
                    
                    </tr>
               
            
                    <?php

                }  }
                ?>
            </tbody>

                
            </Table>
            </div>
        
</body>
</html>
    


