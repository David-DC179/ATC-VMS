<?php
session_start();
require 'db/connection.php';
require '../layout/dash_head.php';
require 'functions.php';
$username = $_SESSION['username'];
$role = $_SESSION['role'];
if(isLoggedIn($username) != true){
    header("Location: ../index.php");
}

?>
<head>
<link rel="stylesheet" href="./asset/bootstrap/css/bootstrap.min.css">
</head>
            
            <div class=" bg-success mt-3 " style=" height: 8vh; width: 100%;">
            <?php 
                    if(isAdmin($role)){ ?>
  
                        <a href="dashbord-Admin.php" class="btn btn-dark m-2">BACK</a>
               <?php  }else{ ?>
                <span class="material-icons-outlined">
    
                        <a href="dashbord-Gurd.php" class="btn btn-dark m-2">BACK</a>
             <?php  }
                ?>
                </div>
      
            </header>
            <div class="col-md-1">
               

            </div>
            
             
                <div class="">
                    <div class="row justify-content-center">
                        <h1 class="h1 fw-bold" style="text-align: center;">LIST OF DEPARTIMENT</h1>
                    </div>
           
  
        <div class="">
            <Table class="table table-hover  table-striped border-success" style="text-align: center;">

                <?php 
                    $select = "SELECT * FROM departiment";

                    $result = mysqli_query($conn,$select);

                    if(mysqli_num_rows($result)>0){
                        
     
                        ?>

                       
                <thead class="table bg-secondary text-light">
                <th>SNO</th>
                <th >NAME</th>
                <th colspan="2">ACTIONS</th>
            
            </thead> 

            <tbody>
                <?php  

                    $sn=1;
                    while($departiment=mysqli_fetch_assoc($result)){  ?>
                    <tr>

                                        

                        <td><?php echo $sn++?></td>
        
                      
                        <td ><?php echo $departiment['name']?></td>
                        <td><a href="departiment_update.php?update=<?php echo$departiment['id'];?>" name="update" class="btn btn-warning sm"><img src="../asset/image/edit.png" alt="avatuser" style="height:30px;"></a>
                        <a href="departiment_delete.php?delete=<?php echo$departiment['id'];?>" name="delete" class="btn btn-danger sm"><img src="../asset/image/delete.png" alt="avatuser" style="height:30px;"></a></td>
                       
                    
                    </tr>
               
            
                    <?php

                }  }
                ?>
            </tbody>
            </Table>
            <a href="inser_departiment.php" class="btn btn-outline-dark fw-bold m-2">ADD NEW DEPARTIMENT</a> 
            <p class="">
                <?php if(isset($_GET['msg'])) echo $_GET['msg'] ?> 
            </p>
        </div>



           
               
            </div>
<?php 
    require '../layout/dash_footer.php';
?>