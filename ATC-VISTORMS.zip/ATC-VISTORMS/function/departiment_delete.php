<?php

require 'db/connection.php';

if(isset($_GET['delete'])){
    $id = $_GET['delete'];

  
    $deleted = "DELETE FROM departiment WHERE id=$id";
    
    

    $query = mysqli_query($conn,$deleted);

  
    if($query){
        $msg= "<p class='alter alert-danger fw-bold text-danger mt-2' style='text-align:center;'>row are deleted</p>";
              
        header("Location:./departiment.php?msg=$msg"); 
    }

    else{
        $msg= " <p class='alter alert-danger fw-bold text-danger mt-2' style='text-align:center;'>row are not deleted</p>";
              

        header("Location:./departiment.php?msg=$msg"); 
    }

}else{
    echo "suuu";
}

?>

