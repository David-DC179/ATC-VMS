<?php

session_start();
require("db/connection.php");
header("Refresh: 60");

require('fpdf/fpdf.php');
	$pdf = new FPDF('L', 'mm', 'A4');
	$pdf->AddPage();

	$pdf->SetFont('Times', 'B', 20);
	$pdf->Cell(32);
	$pdf->Cell(200, 8, 'ATC-VISITORS', 0, 1, 'C');


	$pdf->Ln(10);
	$pdf->SetFont('Arial', 'B', 14);
	$pdf->Cell(100);
	$pdf->Cell(170, 20, 'Report of Atc vistors', 0, 1, 'L');

	$pdf->Line(50, 40, 230, 40);
    $select = "SELECT * FROM vistors";
	$result = mysqli_query($conn,$select);
	$no = 1;
	if (mysqli_num_rows($result)) {
        
     
		$pdf->SetFont('Arial', 'B', 13);
		$pdf->Ln(5);
		$pdf->Cell(10);
		$pdf->Cell(6, 4, 'SN', 1, 0, 'C');
		$pdf->Cell(40, 4, 'Full Name', 1, 0, 'C');
		$pdf->Cell(18, 4, 'Gender', 1, 0, 'C');
		$pdf->Cell(23, 4, 'Addres', 1, 0, 'C');
		$pdf->Cell(27, 4, 'Phone', 1, 0, 'C');
		$pdf->Cell(37, 4, 'Department', 1, 0, 'C');
		$pdf->Cell(37, 4, 'Whose to meet', 1, 0, 'C');
		$pdf->Cell(35, 4, 'Time in', 1, 0, 'C');
		$pdf->Cell(35, 4, 'Time out', 1, 0, 'C');

		while ($row = mysqli_fetch_assoc($result)) {
			$id_dept= $row['departiment_id'];
			$id_employe= $row['employee_id'];

			$selectd= "SELECT name FROM departiment WHERE id='$id_dept'";
			$resultd = mysqli_query($conn,$selectd);
			$departiment=mysqli_fetch_assoc($resultd);

			$selecte= "SELECT name FROM employeeS WHERE id='$id_employe'";
			$resulte = mysqli_query($conn,$selecte);
			$employee=mysqli_fetch_assoc($resulte);
			if($row['time_out'] != 'MM/DD/YYYY HH:MM PM'){
				$pdf->SetFont('Arial', '', 11);
				$pdf->Ln(7);
				$pdf->Cell(10);
				$pdf->Cell(6, 4, $no++, 1, 0, 'C');
				$pdf->Cell(20, 4, $row['first_name'], 1, 0, 'L');
				$pdf->Cell(20, 4, $row['last_name'], 1, 0, 'L');
				$pdf->Cell(18, 4, $row['gender'], 1, 0, 'L');
				$pdf->Cell(23, 4, $row['address'], 1, 0, 'L');
				$pdf->Cell(27, 4, $row['phone'], 1, 0, 'L');
				$pdf->Cell(37, 4, $departiment['name'], 1, 0, 'L');
				$pdf->Cell(37, 4, $employee['name'], 1, 0, 'L');
				$pdf->Cell(35, 4, $row['time_in'], 1, 0, 'L');
				$pdf->Cell(35, 4, $row['time_out'], 1, 0, 'L');
			}
            
		}
	}



	$pdf->Output();


 ?>

 <table>
	 <thead></thead>
 </table>


