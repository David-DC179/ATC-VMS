<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/css/bootstrap.min.css">
    <title>create_path</title>
</head>
<body>
<div id="preloader">
        <div id="status">&nbsp;</div>
    </div>
   <div class="container">
    <div class="row" >
                <div class="col-md-6 col-md-offset-3">
                    <div id="logo-login">
                        <h1>CREATE PASS </h1>
                    </div>
                </div>
    </div>
        <div class="col-md-6 col-md-offset-3">
            <div class="account-box" role="form">
                <form action="" method="post">
                    <div  class="form-group">
                        <label for="">Name</label>
                        <input type="text" name="" id="" class="form-control" require>
                    </div>
                    <div form-group>
                        <label for="">Phone</label>
                        <input type="text" name="" id="" class="form-control" require>
                    </div>
                     <div>
                        <label for="">Address</label>
                        <input type="text" name="" id="" class="form-control" require>
                    </div>
                    <div class="form-group">
                        <label for="">Select Department</label>
                        <select name="" id="" class="form-control" require>
                            <option value="">ICT</option>
                            <option value="">AUTOMOTIVE</option>
                            <option value="">ELETRICAL</option>
                            <option value="">MECHANICAL</option>
                            <option value="">CIVIL</option>
                        </select>
                    </div>
                    <div form-group >
                        <label for="">Gender</label>
                        <select name="" id="" class="form-control" require>
                            <option value="">Male</option>
                            <option value="">Female</option>
                            
                        </select>
                    </div> <br>
                    <div class="form-group">
                        <button class="btn btn btn-primary pull-right" type="submit">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>


<script src="./css/js/bootsrap.min.js"></script>
</body>
</html>