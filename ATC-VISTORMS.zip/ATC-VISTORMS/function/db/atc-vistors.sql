-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jan 31, 2022 at 10:26 PM
-- Server version: 8.0.18
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `atc-vistors`
--

-- --------------------------------------------------------

--
-- Table structure for table `departiment`
--

DROP TABLE IF EXISTS `departiment`;
CREATE TABLE IF NOT EXISTS `departiment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `departiment`
--

INSERT INTO `departiment` (`id`, `name`) VALUES
(1, 'ICT'),
(3, 'Electrical Eng'),
(4, 'Civil Eng'),
(8, 'Automotive Eng'),
(9, 'Library');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
CREATE TABLE IF NOT EXISTS `employees` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `gender` varchar(10) COLLATE utf8mb4_general_ci NOT NULL,
  `age` varchar(10) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `phonenumber` varchar(15) COLLATE utf8mb4_general_ci NOT NULL,
  `departiment_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `departiment_id` (`departiment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `name`, `gender`, `age`, `email`, `phonenumber`, `departiment_id`) VALUES
(6, 'Mr govela', 'Male', '42', 'govela', '0765432356', 8),
(21, 'David Christopher', 'Male', '35', 'davidchristophersenior@gmail.com', '0755646746', 1),
(23, 'rabin hasan', 'male', '23', 'david@gmail.com', '0623657432', 3),
(24, 'Student', 'male', '1', 'student', '0976', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `username` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `gender` varchar(10) COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(10) COLLATE utf8mb4_general_ci NOT NULL,
  `phonenumber` varchar(15) COLLATE utf8mb4_general_ci NOT NULL,
  `role` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `gender`, `password`, `phonenumber`, `role`) VALUES
(21, 'rabin hasan', 'Rb', 'male', '123', '07365546', 'Gurd'),
(22, 'habibu jumanne', 'grand', 'male', '123', '1234567890', 'Admin'),
(23, 'David', 'DC', 'male', '1234', '0764063426', 'Admin');

-- --------------------------------------------------------

--
-- Table structure for table `vistors`
--

DROP TABLE IF EXISTS `vistors`;
CREATE TABLE IF NOT EXISTS `vistors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `gender` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `address` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8mb4_general_ci NOT NULL,
  `departiment_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `time_in` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'MM/DD/YYYY HH:MM PM',
  `time_out` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'MM/DD/YYYY HH:MM PM',
  PRIMARY KEY (`id`),
  KEY `departiment_id` (`departiment_id`),
  KEY `employee_id` (`employee_id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vistors`
--

INSERT INTO `vistors` (`id`, `first_name`, `last_name`, `gender`, `address`, `phone`, `departiment_id`, `employee_id`, `time_in`, `time_out`) VALUES
(23, 'jackyy', 'lasway', 'Female', '15341', '0752932680', 3, 1, '2022-01-29T19:36', '2022-01-30T13:21'),
(24, 'habibu', 'jumanne', 'Male', '15341', '0752932680', 1, 6, '2022-02-05T19:44', '2022-01-30T13:21'),
(25, 'urio', 'godson', 'Male', 'mianzin', '0752932680', 3, 6, '2022-02-01T12:26', '2022-01-30T13:21'),
(26, 'urio', 'jumanne', 'Male', 'samunge', '2020202020', 8, 6, '2022-01-30T13:16', '2022-01-30T13:25'),
(28, 'sayi', 'yona', 'Female', 'samunge', '1010101020', 8, 6, '2022-01-30T14:04', '2022-01-30T14:10'),
(29, 'habibu', 'jumanne', 'Male', 'mianzini', '4040404040', 3, 21, '2022-01-30T14:17', '2022-01-30T14:21'),
(30, 'jackyy', 'yona', 'Female', 'mianzini', '3030303030', 1, 23, '2022-01-30T14:23', '2022-01-30T14:24'),
(31, 'habibu', 'lasway', 'Male', 'mianzin', '4030303030', 4, 21, '2022-01-31T07:42', '2022-01-31T07:48'),
(32, 'Yasinta', 'Paulo', 'Female', 'sakina', '0764063426', 1, 21, '2022-01-31T10:56', '2022-01-31T11:55'),
(33, 'Annastazia', 'Christopher', 'Female', 'Dar es salaam', '0678586399', 9, 6, '2022-01-31T12:00', '2022-01-29T12:03'),
(34, 'jackyy', 'jumanne', 'Female', 'Chunya', '2020202020', 9, 23, '2022-01-31T12:07', '2022-01-31T12:08'),
(35, 'habibu', 'lasway', 'Male', 'Moshi', '09999999', 9, 23, '2022-01-31T12:09', '2022-02-03T12:10'),
(36, 'son', 'son', 'Female', 'China', '0222222', 9, 21, '2022-01-31T12:11', '2022-01-31T12:12'),
(37, 'jackyy', 'jumanne', 'Female', 'samunge', '2020202020', 4, 24, '2022-01-31T15:51', 'MM/DD/YYYY HH:MM PM'),
(38, 'urio', 'yona', 'Male', 'sakina', '2020202020', 4, 23, '2022-02-01T01:03', 'MM/DD/YYYY HH:MM PM');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
