<?php
    $conn = mysqli_connect("localhost","root","","atc-vistors") or die("coluld not connect");