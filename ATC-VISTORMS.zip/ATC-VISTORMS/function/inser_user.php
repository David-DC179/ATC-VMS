<?php
require 'db/connection.php';
require "sanitization.php";
session_start();
require 'functions.php';
$username = $_SESSION['username'];
$role = $_SESSION['role'];
if(!isLoggedIn($username)){
    header("Location: ../index.php");
}
if(!isAdmin($role)){
    header("Location: ../index.php");
}
require '../layout/dash_head.php';

 if(isset($_POST['save'])){
    
     $name = mysqli_real_escape_string($conn, dataSanitizations($_POST['name']));
     $username = mysqli_real_escape_string($conn, dataSanitizations($_POST['username']));
     $gender = mysqli_real_escape_string($conn, dataSanitizations($_POST['gender']));
     $password = mysqli_real_escape_string($conn, dataSanitizations($_POST['password']));
     $phonenumber= mysqli_real_escape_string($conn, dataSanitizations($_POST['phonenumber']));
     $role = mysqli_real_escape_string($conn, dataSanitizations($_POST['role']));
             
    $insert = "INSERT INTO users (name, username, gender, password, phonenumber, role) VALUES ('$name', '$username', '$gender', '$password', '$phonenumber', '$role')";
        $query = mysqli_query($conn,$insert);
     $msg = "";
     if($query){
         $msg= "<p class='alert alert-warning  fw-bold text-warning mt-2' style='text-align:center;' >row are inserted</p>";
        header("location:manageuser.php?msg=$msg");  
     }
     else{
        
         $msg= "<p class='alert alert-danger  fw-bold text-danger mt-2' style='text-align:center;'>row are not inserted</p>";
        header("location:manageuse.php?msg=$msg");

        
     }
   
}

?>
        <div class=" bg-success mt-3 " style=" height: 8vh; width: 100%;">
                <?php 
                    if(isAdmin($role)){ ?>
                        <a href="manageuser.php" class="btn btn-dark m-2">BACK</a>

               <?php  }else{ ?>
                        <a href="dashbord-Gurd.php" class="btn btn-dark m-2">BACK</a>
             <?php  }
                ?>
                </div>
            </header>
            <div class="col-md-1">
               

            </div>
            
         
            
                <div class="col-md-12 col-md-offset-3">
                    <div class="row justify-content-center">
                        <h1 class="h3 fw-bold" style="text-align: center;">ADD NEW USER </h1>
                    </div>
           
  
        <div class="col-md-4  ">
            
            <div class="card ">
                <div class="card-head"></div>
                <div class="card-body p-5">
                    <form action="" method="post">
                        <div class="form-group">
                            <label for="">Full name</label>
                            <input type="text" name="name" class="form-control" id="">
                        </div>
                        <div class="form-group">
                               <label for="">Username</label>
                            <input type="text" name="username" class="form-control" id="">
                        </div>
                        <div class="form-group">
                               <label for="">Gender</label>
                            <input type="text" name="gender" class="form-control" id="">
                        </div>
                        <div class="form-group">
                               <label for="">Phone Number</label>
                            <input type="text" name="phonenumber" class="form-control" id="">
                        </div>
                        <div class="form-group">
                            <label for="">Role</label>
                                <select name ="role" class="form-control">
                                    <option value="">Select role</option>
                                    <option value="Admin">Admin</option>
                                    <option value="Gurd">Gurd</option>
                                </select>
                            
                        </div>
                        <div class="form-group">
                               <label for="">Password</label>
                            <input type="text" name="password" class="form-control" id="">
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-info form-control mt-4" name="save">Save</button>
                        </div>
                    </form>
                </div>
            </div>
                                    
<?php 
    require '../layout/dash_footer.php';
?>