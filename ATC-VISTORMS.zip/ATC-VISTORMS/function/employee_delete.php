<?php
require 'db/connection.php';
session_start();
header("Refresh: 60");
require 'functions.php';
$username = $_SESSION['username'];
$role = $_SESSION['role'];
if(!isLoggedIn($username)){
    header("Location: ../index.php");
}
if(!isAdmin($role)){
    header("Location: ../index.php");
}

if(isset($_GET['delete'])){
    $id = $_GET['delete'];

    $deleted = "DELETE FROM employees WHERE id=$id";
    
    

    $query = mysqli_query($conn,$deleted);


    
    if($query){
        $msg= "<p class='alter alert-danger fw-bold text-danger mt-2' style='text-align:center;'>row are deleted</p>";
              
        header("Location:./employee.php?msg=$msg"); 
    }

    else{
        $msg= " <p class='alter alert-danger fw-bold text-danger mt-2' style='text-align:center;'>row are not deleted</p>";
              

        header("Location:./employee.php?msg=$msg"); 
    }

}else{
    echo "suuu";
}
?>

