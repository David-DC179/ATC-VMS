<?php
require 'db/connection.php';
require "sanitization.php";

if(isset($_POST['save'])){
    $firstname = $_POST['firstname'];
    $lastname = mysqli_real_escape_string($conn, dataSanitizations($_POST['lastname']));
    $gender = mysqli_real_escape_string($conn, dataSanitizations($_POST['gender']));
    $phone = mysqli_real_escape_string($conn, dataSanitizations($_POST['phone']));
    $address = mysqli_real_escape_string($conn, dataSanitizations($_POST['address']));
    $departiment = mysqli_real_escape_string($conn, dataSanitizations($_POST['departiment']));
    $employee = mysqli_real_escape_string($conn, dataSanitizations($_POST['employee']));
    $timein = $_POST['timein'];mysqli_real_escape_string($conn, dataSanitizations($_POST['timein']));

   
    $selectd = "SELECT id FROM departiment where name='$departiment'";
    $query_d = mysqli_query($conn,$selectd);

    $selecte = "SELECT id FROM employees where name='$employee'";
    
    $query_e = mysqli_query($conn,$selecte);

            $departiment = mysqli_fetch_assoc($query_d); 
            $departiment_id = $departiment['id'];


            $employee = mysqli_fetch_assoc($query_e); 
            $employee_id = $employee['id'];
            
            

           $insert = "INSERT INTO vistors(first_name,last_name,gender,address,phone,departiment_id,employee_id,time_in)
                                VALUES('$firstname','$lastname','$gender','$address','$phone',$departiment_id,$employee_id,'$timein')";
                
                                
                                


                                $query = mysqli_query($conn,$insert);

                                if($query){
                                    
                                    header("location:dashbord-gurd.php");
                                    echo "added";
                                }
                                else{
                                    echo "jaribu tena";
                                }
                            }
  