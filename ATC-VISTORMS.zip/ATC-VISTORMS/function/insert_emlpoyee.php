<?php
require 'db/connection.php';
require "sanitization.php";
session_start();
require 'functions.php';
$username = $_SESSION['username'];
$role = $_SESSION['role'];
if(!isLoggedIn($username)){
    header("Location: ../index.php");
}
if(!isAdmin($role)){
    header("Location: ../index.php");
}

 if(isset($_POST['save'])){
    
     $name = mysqli_real_escape_string($conn, dataSanitizations($_POST['name']));
     $gender = mysqli_real_escape_string($conn, dataSanitizations($_POST['gender']));
     $age = mysqli_real_escape_string($conn, dataSanitizations($_POST['age']));
     $email = mysqli_real_escape_string($conn, dataSanitizations($_POST['email']));
     $phone= mysqli_real_escape_string($conn, dataSanitizations($_POST['phone']));
     $departiment = mysqli_real_escape_string($conn, dataSanitizations($_POST['departiment']));

     $selectd = "SELECT id FROM departiment where name='$departiment'";
     $query_d = mysqli_query($conn,$selectd);
         $departiment = mysqli_fetch_assoc($query_d); 
             $departiment_id = $departiment['id'];

           

             
    $insert = "INSERT INTO employees (name, gender, age, email, phonenumber, departiment_id) VALUES ('$name', '$gender', '$age', '$email', '$phone', $departiment_id)";
        $query = mysqli_query($conn,$insert);
     $msg = "";
     if($query){
         $msg= "<p class='alert alert-warning  fw-bold text-warning mt-2' style='text-align:center;' >row are inserted</p>";
        header("location:employee.php?msg=$msg");  
     }
     else{
        
         $msg= "<p class='alert alert-danger  fw-bold text-danger mt-2' style='text-align:center;'>row are not inserted</p>";
        header("location:employee.php?msg=$msg");

        
     }
   
}
require '../layout/dash_head.php';

?>

                <div class=" bg-success mt-3 " style=" height: 8vh; width: 100%;">
                    <a href="employee.php" class="btn btn-dark m-2">BACK</a>
                    
                </div>
      
            </header>
            <div class="col-md-1">
               

            </div>
            
         
            
                <div class="col-md-12 col-md-offset-3">
                    <div class="row justify-content-center">
                        <h1 class="h3 fw-bold" style="text-align: center;">ADD NEW EMPLOYEE </h1>
                    </div>
           
  
        <div class="col-md-4  ">
            
            <div class="card p-5">
                <div class="crad-body">
                    <form action="" method="post">
                        <div class="form-group">
                            <label for="">Name</label>
                            <input type="text" name="name" class="form-control" id="">
                        </div>
                        <div class="form-group">
                            <label for="">Gender</label>
                            <input type="text" name="gender"  class="form-control" id="">
                        </div>
                        <div class="form-group">
                            <label for="">Age</label>
                            <input type="text" name="age" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="">Email</label>
                            <input type="email" name="email" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="">Phone</label>
                            <input type="text" name="phone"  class="form-control" id="">
                        </div>
                        <!-- <div class="form-group">
                            <label for="">Departiment</label>
                            <input type="text" name="departiment"  class="form-control" id="">
                        </div> -->

                        <div class="form-group">
                        <label for="departiment">Select Department</label>
                       
                        <select name="departiment" id="" class="form-control"  require>
                            <option value="0">Select Departiment</option>
                            <?php
                                $select1 = "SELECT * FROM departiment";

                                $query = mysqli_query($conn,$select1);

                                if($rows=mysqli_num_rows($query)){
                                    
                                    
                                    while($departiment = mysqli_fetch_assoc($query)){
                                       $dept= $departiment['name'];
                                        
                                        ?>
                                       
                                        <option value="<?= $dept ?>" ><?php echo $dept ?></option>
                                     
                                            
                        <?php }


                                }
                            ?>
                            
                        </select>
                    </div>

                        <div class="form-group">
                            <button type="submit" name="save" class="btn btn-success mt-2 form-control">Save</button>
                        </div>

                    </form>
                    <?php if(isset($_GET['msg'])) echo $_GET['msg'] ?> 
                </div>
            </div>


       
        </div>
        


       
    </div>
    </div>
            </div>
            </div>
    
<link rel="stylesheet" href="../asset/bootstrap/css/bootstrap.min.css">
    <div class="container">
  <script src="../asset/bootstrap/js/bootstrap.bundle.js"></script>
</div> 
</body>
</html>