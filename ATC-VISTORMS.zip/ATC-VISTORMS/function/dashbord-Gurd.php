<?php 
    session_start();
    require 'functions.php';
    $username = $_SESSION['username'];
    $role = $_SESSION['role'];
    if(!isLoggedIn($username)){
        header("Location: ../index.php");
    }
    if(isAdmin($role)){
        header("Location: ../index.php");
    }
    
    require '../layout/dash_head.php';
?> 
 <head>
        <link rel="stylesheet" href="./asset/bootstrap/css/bootstrap.min.css">
</head>
<style>
    caption{
        margin: 5%;
    }
</style>
<body>
    
<div class=" col-md-16 bg-success mt-3 " style=" height: 8vh; width: 100%;">
                    <nav class="nav nav-masthead justify-content-center float-md-end p-2 ">
                    <span class=" float-md-start p-2 text-light">
                                <img src="../asset/image/time.png" alt="users" style="height:30px;">
                          <?php        date_default_timezone_set("Africa/Nairobi");
                      echo date("d-m-Y h:i:sa");?>  
                                </span>&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;
                                &nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;
                                &nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;
                                &nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;
                                &nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;
                                &nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; 
                       
                      
                      
                
                    <p class="h4 text-light me-5">Welcome Guard <span class="text-dark"> <?php echo $username; ?></span>  </p>
                    <a href="../function/logout.php" class="btn btn-dark text-light  "  aria-current="page">Logout <img src="../asset/image/logout.png" alt="avatuser" style="height:20px;"></a>
                    
                    </nav>
                </div><br>
    <div class="container ">

            
                
     <center><h1>DASHBORD</h1></center>
            <div class="container"><br>
               
              <div class="container col-md-6">
            <center>
                <caption> <a href="createpass.php" class="btn  btn-sm">
                <img src="../asset/image/register1.png" alt="avatuser" style="height:100px;"><br>    
                CREATE PASS</a></caption>&nbsp;
                
            
                
                <caption> <a href="checkout.php" class="btn  btn-sm">
                <img src="../asset/image/check1.jfif" alt="avatuser" style="height:100px;"><br>    
                CHECK OUT</a></caption>&nbsp;

                <caption> <a href="vistors.php" class="btn  btn-sm">
                <img src="../asset/image/batche2.jfif" alt="avatuser" style="height:100px;"><br>    
                VISTORS</a></caption>


</center>
            </div>
            </div>
            
            </div>
        
            <?php 
    require '../layout/dash_footer.php';
?>

            <script src="./asset/bootstrap/js/bootstrap.min."></script>
            </body>
