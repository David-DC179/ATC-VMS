<?php
require 'db/connection.php';
require "sanitization.php";
session_start();
require 'functions.php';
$errors = array();
if (isset($_POST['login'])) {
    $username = mysqli_real_escape_string($conn, dataSanitizations($_POST['username']));
    $password = mysqli_real_escape_string($conn, dataSanitizations($_POST['password']));
    global $errors; 
    if (empty($username)) {
        array_push($errors, "username is required");
    }
    
    if (empty($password)) {
        array_push($errors, "Password is required");
    }

    if (empty($errors)) {
        $query = "SELECT * FROM users WHERE username = '$username'";
        $result = mysqli_query($conn, $query);
        if (mysqli_num_rows($result) == 1) {
            $user = mysqli_fetch_assoc($result);
            $usr = $user['username'];
            $pwd = $user['password'];
            if ($username== $usr && $password == $pwd) {
                $_SESSION['username'] = $user['username'];
                $_SESSION['role'] = $user['role'];
                $rol = $_SESSION['role'];
                if($rol == 'Admin'){
                    header("Location: function/dashbord-Admin.php");
                }else if($rol == 'Gurd'){
                    header("Location: function/dashbord-Gurd.php");
                }else{
                    array_push($errors, "Invalid credentials");
                }
                
            } else {
                array_push($errors, "Invalid credentials");
                
            }
        } else {

            array_push($errors, "Invalid credentials");

        }
    }
}
?>