<?php
require 'db/connection.php';
require "sanitization.php";
session_start();
require 'functions.php';
$username = $_SESSION['username'];
$role = $_SESSION['role'];
if(!isLoggedIn($username)){
    header("Location: ../index.php");
}
if(!isAdmin($role)){
    header("Location: ../index.php");
}

 if(isset($_GET['update'])){
    $id = $_GET['update'];

 
    $select="SELECT * FROM departiment WHERE id=$id";

    $result = mysqli_query($conn,$select);

   

   if(mysqli_num_rows($result)){
       $users = mysqli_fetch_assoc($result);
   }

 }

 if(isset($_POST['update'])){
    $id = $_GET['update'];
     $name = mysqli_real_escape_string($conn, dataSanitizations($_POST['name']));
     
     $update = "UPDATE departiment SET name='$name' WHERE id=$id";
   
     $query = mysqli_query($conn,$update);

     $msg = "";
     if($query){
         $msg= "<p class='alert alert-warning  fw-bold text-warning mt-2' style='text-align:center;' >row are updated</p>";
        header("location:departiment.php?msg=$msg");  
     }
     else{
        
         $msg= "<p class='alert alert-danger  fw-bold text-danger mt-2' style='text-align:center;'>row are not updated</p>";
        header("location:departiment.php?msg=$msg");

        
     }
   
}


 

require '../layout/dash_head.php';

?>


            <div class=" bg-success mt-3 " style=" height: 8vh; width: 100%;">
            <?php 
                    if(isAdmin($role)){ ?>
                        <a href="dashbord-Admin.php" class="btn btn-dark m-2">BACK</a>

               <?php  }else{ ?>
                        <a href="dashbord-Gurd.php" class="btn btn-dark m-2">BACK</a>
             <?php  }
                ?>
                </div>
      
            </header>
            <body>
            <div class="col-md-1">
               

               </div>
               
                
                   <div class="col-md-12 col-md-offset-3">
                       <div class="row justify-content-center">
                           <h1 class="h3 fw-bold" style="text-align: center;">UPDATE DEPARTIMENT INFORMATION</h1>
                       </div>
              
   <div class="container">
       <div class="row justify content-center">
           <div class="col-md-6">
               <div class="card">
                   
                   <div class="card-body">
                       <form action="" method="post">
                           <div class="form-group">
                               <label for="">Full name</label>
                               <input type="text" value="<?php  echo $users['name']; ?>" name="name" class="form-control">
                           </div>
   
                           <div class="form-group">
                               <button type="submit" class="btn btn-warning mt-3 form-control" name="update">Update</button>
                           </div>
   
                       </form>
                   </div>
               </div>
           </div>
<?php 
    require '../layout/dash_footer.php';

?>