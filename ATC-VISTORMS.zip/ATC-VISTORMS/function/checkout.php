<?Php
require 'db/connection.php';
require "sanitization.php";

if(isset($_POST['checkout'])){
    $phone= mysqli_real_escape_string($conn, dataSanitizations($_POST['phonenumber']));
    $timeout =$_POST['timeout'];


    $select="SELECT * FROM vistors WHERE phone='$phone' ";

    $result = mysqli_query($conn,$select);

   if(mysqli_num_rows($result)){
       $row = mysqli_fetch_assoc($result);
       

      $update = "UPDATE vistors SET time_out='$timeout' WHERE phone='$phone' AND time_out = 'ACTIVE'";
    
      $query = mysqli_query($conn,$update);

      $msg = "";
      if($query && $row['time_out'] == 'ACTIVE'){
          $msg= "<p class='alert alert-warning  fw-bold text-warning mt-2' style='text-align:center;' >VISTER CHEKED OUT</p>";
         header("location:checkout.php?msg=$msg");  
      }
     else{
             $msg= "<p class='alert alert-danger  fw-bold text-danger mt-2' style='text-align:center;'>Visitor already check out</p>";
             header("location:checkout.php?msg=$msg");
     } 
      
  
   }
   else {
        $msg= "<p class='alert alert-danger  fw-bold text-danger mt-2' style='text-align:center;'>ops! wrong number ?!</p>";
        header("location:checkout.php?msg=$msg");
   }
}

// // header("loacation:checkout.php");
require '../layout/dash_head.php';

?>
<head>
<link rel="stylesheet" href="./asset/bootstrap/css/bootstrap.min.css">
</head>

<div class=" bg-success mt-3 " style=" height: 8vh; width: 100%;">
<div class=" bg-success mt-3 " style=" height: 8vh; width: 100%;">
            <a href="dashbord-Gurd.php" class="btn btn-dark m-2">BACK</a>
               
            </div>
  
</div>

     
<div class="container">
    <br><br>
<center><h1>CHECK OUT VISTOR </h1></center>
<br><br>
    <div class="container col-md-6">
            
        

    
        <div class="account-box" role="form">
            <form action="" method="post">
                <div class="form-group">
                    <label for="">Enter Vistopr Phone number</label>
                    <input type="text" name="phonenumber" class="form-control" placeholder="eg 0764063426">
                </div>
                <div  class="form-group">
                    <label for="">Time OUT</label>
                    <input type="datetime-local" name="timeout" id="" class="form-control" > 
                    
                </div>

                
               
                <div class="form-group mt-4">
                    <button type="submit" class="btn btn btn-success pull-right form-control"  name="checkout">checkout</button>
                </div>
            </form>
            
        </div>
        <?php if(isset($_GET['msg'])) echo $_GET['msg'] ?>
    </div>



       
</div> 
    </div>
    </div>
    <?php 
    require '../layout/dash_footer.php';
?>