<?php
require 'db/connection.php';
require "sanitization.php";
session_start();
header("Refresh: 60");
require 'functions.php';
$username = $_SESSION['username'];
$role = $_SESSION['role'];
if(!isLoggedIn($username)){
    header("Location: ../index.php");
}
if(!isAdmin($role)){
    header("Location: ../index.php");
}

 if(isset($_POST['save'])){
    
     $name = mysqli_real_escape_string($conn, dataSanitizations($_POST['name']));
     
    $insert = "INSERT INTO departiment (name) VALUES ('$name')";
        $query = mysqli_query($conn,$insert);
     $msg = "";
     if($query){
         $msg= "<p class='alert alert-warning  fw-bold text-warning mt-2' style='text-align:center;' >row are inserted</p>";
        header("location:departiment.php?msg=$msg");  
     }
     else{
        
         $msg= "<p class='alert alert-danger  fw-bold text-danger mt-2' style='text-align:center;'>row are not inserted</p>";
        header("location:departiment.php?msg=$msg");

        
     }
   
}

require '../layout/dash_head.php';

?>

            
                <div class="col-md-12 col-md-offset-3">
                    <div class="row justify-content-center">
                        <h1 class="h3 fw-bold" style="text-align: center;">ADD NEW DEPARTIMENT </h1>
                    </div>
           
  
        <div class="col-md-4  ">
            
            <div class="card ">
                <div class="card-head"></div>
                <div class="card-body p-5">
                    <form action="" method="post">
                        <div class="form-group">
                            <label for="">Department name</label>
                            <input type="text" name="name" class="form-control" id="">
                        </div>
                        
                        <div class="form-group">
                            <button type="submit" class="btn btn-info form-control mt-4" name="save">Save</button>
                        </div>
                    </form>
                </div>
            </div>
                                    
<?php 
require '../layout/dash_footer.php';
?>