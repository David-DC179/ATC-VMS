<?php
require 'db/connection.php';
session_start();
header("Refresh: 60");
require 'functions.php';
$username = $_SESSION['username'];
$role = $_SESSION['role'];
if(!isLoggedIn($username)){
    header("Location: ../index.php");
}
if(!isAdmin($role)){
    header("Location: ../index.php");
}
require '../layout/dash_head.php';


?>
<head>
<link rel="stylesheet" href="./asset/bootstrap/css/bootstrap.min.css">
</head>


                <div class=" bg-success mt-3 " style=" height: 8vh; width: 100%;">
                <?php 
                    if(isAdmin($role)){ ?>
                        <a href="dashbord-Admin.php" class="btn btn-dark m-2">BACK</a>

               <?php  }else{ ?>
                        <a href="dashbord-Gurd.php" class="btn btn-dark m-2">BACK</a>
             <?php  }
                ?>
                </div>
      
            
            
         
               <center><h1 >LIST OF EMPLOYEE</h1></center>
               <div class="container">
                    <div class="table-responsive">
            <Table class="table table-hover  table-striped border-success" style="text-align: center;">

                <?php 
                    $select = "SELECT * FROM employees";

                    $result = mysqli_query($conn,$select);

                    if(mysqli_num_rows($result)>0){
                        
     
                        ?>

                       
                <thead class="table bg-dark text-light">
                <th>SNO</th>
                <th colspan="">FULL NAME</th>
                <th>GENDER</th>
                <th>AGE</th>
                 <th>EMAIL</th>
                 <th>PHONE</th>
                <th colspan="2">DEPARTMENT</th>
                <th colspan="2">ACTIONS</th>
            
            </thead> 

            <tbody>
                <?php  

                    $sn=1;
                    while($users=mysqli_fetch_assoc($result)){

                        $id_dept= $users['departiment_id'];
                       

                        $selectd= "SELECT name FROM departiment WHERE id='$id_dept'";
                        $resultd = mysqli_query($conn,$selectd);
                        $departiment=mysqli_fetch_assoc($resultd);

                        
                    ?>
                    <tr>

                                        

                        <td><?php echo $sn++?></td>
                    <td><?php echo $users['name']?></td>
                    <td><?php echo $users['gender']?></td>                    
                    <td><?php echo $users['age']?></td>
                    <td><?php echo $users['email']?></td>
                    <td><?php echo $users['phonenumber']?></td>
                    <td colspan="2"><?php echo $departiment['name']?></td>
                    <td><a href="employee_update.php?update=<?php echo$users['id'];?>" name="update" class="btn btn-warning sm"><img src="../asset/image/edit.png" alt="avatuser" style="height:30px;"></a>
                    <a href="employee_delete.php?delete=<?php echo$users['id'];?>" name="delete" class="btn btn-danger sm"><img src="../asset/image/removep.png" alt="avatuser" style="height:30px;"><br>   </a></td>
                    
                    
                    
                    </tr>
               
            
                    <?php

                }  }
                ?>
            </tbody>

                
            </Table>
            <a href="insert_emlpoyee.php" class="btn btn-outline-dark fw-bold m-2">ADD NEW EMPLOYEE</a>
            
        </div>
        
                <?php if(isset($_GET['msg'])) echo $_GET['msg'] ?> 
           

                </div>

                </div>
                </div>
<?php 
    require '../layout/dash_footer.php';
?>