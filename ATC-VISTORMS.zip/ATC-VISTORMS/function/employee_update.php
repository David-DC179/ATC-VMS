<?php
require 'db/connection.php';
require "sanitization.php";
session_start();
header("Refresh: 60");
require 'functions.php';
$username = $_SESSION['username'];
$role = $_SESSION['role'];
if(!isLoggedIn($username)){
    header("Location: ../index.php");
}
if(!isAdmin($role)){
    header("Location: ../index.php");
}

 if(isset($_GET['update'])){

    $id = $_GET['update'];

 
    $select="SELECT * FROM employees WHERE id=$id";

    $result = mysqli_query($conn,$select);

   

   if(mysqli_num_rows($result)){
       $employee = mysqli_fetch_assoc($result);
   }

   
 }

 if(isset($_POST['update'])){
    $id = $_GET['update'];
     $name = mysqli_real_escape_string($conn, dataSanitizations($_POST['name']));
     $gender = mysqli_real_escape_string($conn, dataSanitizations($_POST['gender']));
     $age = mysqli_real_escape_string($conn, dataSanitizations($_POST['age']));
     $email = mysqli_real_escape_string($conn, dataSanitizations($_POST['email']));
     $phone= mysqli_real_escape_string($conn, dataSanitizations($_POST['phone']));
     $departiment = mysqli_real_escape_string($conn, dataSanitizations($_POST['departiment']));

     
    $selectd = "SELECT id FROM departiment where name='$departiment'";
    $query_d = mysqli_query($conn,$selectd);
    $departiment = mysqli_fetch_assoc($query_d); 
            $departiment_id = $departiment['id'];

   
     $update = "UPDATE employees SET name='$name', gender='$gender', age='$age', email='$email', phonenumber='$phone', departiment_id=$departiment_id WHERE id=$id";
   
     $query = mysqli_query($conn,$update) or die("erroo");

     $msg = "";
     if($query){
         $msg= "<p class='alert alert-warning  fw-bold text-warning mt-2' style='text-align:center;' >row are updated</p>";
        header("location:employee.php?msg=$msg");  
     }
     else{
        
         $msg= "<p class='alert alert-danger  fw-bold text-danger mt-2' style='text-align:center;'>row are not updated</p>";
        header("location:employee.php?msg=$msg");

        
     }
   
}
require '../layout/dash_head.php';

?>

            <div class=" bg-success mt-3 " style=" height: 8vh; width: 100%;">
                <?php 
                    if(isAdmin($role)){ ?>
                        <a href="employee.php" class="btn btn-dark m-2">BACK</a>

               <?php  }else{ ?>
                        <a href="dashbord-Gurd.php" class="btn btn-dark m-2">BACK</a>
             <?php  }
                ?>
                </div>
      
            </header>
            <div class="col-md-1">
               

            </div>
            
         
            
                <div class="col-md-12 col-md-offset-3">
                    <div class="row justify-content-center">
                        <h1 class="h3 fw-bold" style="text-align: center;">UPDATE EMPLOYEE INFORMATION</h1>
                    </div>
           
  
        <div class="col-md-4  ">
            
            <div class="card p-5">
                <div class="crad-body">
                    <form action="" method="post">
                        <div class="form-group">
                            <label for="">Name</label>
                            <input type="text" name="name" value="<?php echo $employee['name'];?>" class="form-control" id="">
                        </div>
                        <div class="form-group">
                            <label for="">Gender</label>
                            <input type="text" name="gender" value="<?php echo $employee['gender'];?>" class="form-control" id="">
                        </div>
                        <div class="form-group">
                            <label for="">Age</label>
                            <input type="text" name="age" value="<?php echo $employee['age'];?>" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="">Email</label>
                            <input type="text" name="email" value="<?php echo $employee['email'];?>" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="">Phone</label>
                            <input type="text" name="phone" value="<?php echo $employee['phonenumber'];?>" class="form-control" id="">
                        </div>
                      

                        <div class="form-group">
                        <label for="departiment">Select Department</label>
                       
                        <select name="departiment" id="" class="form-control"  require>
                            <option value="0">Select Departiment</option>
                            <?php
                                $select1 = "SELECT * FROM departiment";

                                $query = mysqli_query($conn,$select1);

                                if($rows=mysqli_num_rows($query)){
                                    
                                    
                                    while($departiment = mysqli_fetch_assoc($query)){
                                       $dept= $departiment['name'];
                                        
                                        ?>
                                       
                                        <option value="<?= $dept ?>" ><?php echo $dept ?></option>
                                     
                                            
                        <?php }


                                }
                            ?>
                            
                        </select>
                    </div>

                        <div class="form-group">
                            <button type="submit" name="update" class="btn btn-warning mt-2 form-control">Update</button>
                        </div>

                    </form>
                    <?php if(isset($_GET['msg'])) echo $_GET['msg'] ?> 
                </div>
            </div>


       
<?php 
    require '../layout/dash_footer.php';

?>